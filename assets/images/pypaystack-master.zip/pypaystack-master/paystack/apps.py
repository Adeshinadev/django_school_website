from django.apps import AppConfig


class PaystackConfig(AppConfig):
    name = 'paystack'
